package com.example.lesson_flutter_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
